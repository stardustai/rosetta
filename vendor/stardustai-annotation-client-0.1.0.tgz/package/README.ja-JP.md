# @stardustai/annotation-client

[English](README.md) | [简体中文](README.zh-CN.md) | [Deutsch](README.de-DE.md) | **日本語**

standalone ワークスペースと Rosetta のアノテーションサービスを iframe で接続する React クライアントです。描画画面、ツール設定、アルゴリズム設定を提供します。描画エンジンとログイン処理は、接続先の iframe 内で動作します。

![クライアントから接続した日本語エディター](docs/images/05-editor-ja.jpg)

## 準備するもの

動作中のアノテーションサービスと、その完全な HTTPS URL を用意します。サービスの `VITE_HOST_ORIGINS` に、組み込み先アプリの Origin を追加してください。Origin はスキーム、ホスト、必要に応じてポートを含みます。アプリのパスは含みません。

## アプリに組み込む

`RosettaProvider` の内側にコンポーネントを配置します。以下のデータとコールバックは、組み込み先で用意してください。

```tsx
import {
  configureRosetta,
  RosettaAnnotation,
  RosettaProvider,
} from '@stardustai/annotation-client';

configureRosetta({
  frameURL: 'https://annotation.example.com/',
  language: 'ja-JP',
  readResource: readLocalBlobOrSignedURL,
  saveFile: persistGeneratedFile,
});

<RosettaProvider>
  <RosettaAnnotation
    taskId={task.id}
    input={task.input}
    language={language}
    onSave={saveTask}
    onProtectionSave={saveRecoveryDraft}
  />
</RosettaProvider>;
```

`task.input` の型は `PublicAnnotationInput`、`language` には `'ja-JP'` などを指定します。`readResource` は Blob または署名付き URL を返します。`saveFile` は生成されたファイルを保存し、参照先を返します。`onSave` が受け取るのは、結果、パラメーター、データのインデックス、下書きです。書き込みが終わってから Promise を解決してください。`onProtectionSave` でも、復元用のローカル保存の完了を待ちます。

`OperatorsEditor` と `AlgorithmEditor` は、`onInputChange` で設定変更を返します。アノテーションコンポーネントの ref には、`captureDraft`、`authorizeSave`、`confirmSave`、`authorizeExport` があります。認証とライセンスの確認は、iframe 内のサービスが行います。

## 言語を切り替える

既定は英語です。`en-US`、`zh-CN`、`de-DE`、`ja-JP` に対応しています。共通の設定で初期言語を指定できますが、個別の `language` プロパティが優先されます。プロパティを省略すると、クライアントが共有する i18next の言語に従います。

```tsx
<RosettaAnnotation input={input} language="de-DE" />
```

最初の iframe URL には `lng` が入り、初期化時に同じ値を `FrameInput.language` として送信します。接続後の変更には、省略可能な `FrameEditor.setLanguage` を使います。言語の変更だけでは `updateInput` を呼び出さず、iframe の再接続や下書きのリセットも行いません。古いサービスはこのメソッドを省略できますが、その場合、実行中の切り替えにはサービスの更新が必要です。

## 接続を確認する

1. 既存のツール設定がある画像を開き、iframe に画像とツールバーが表示されることを確認します。
2. 日本語とドイツ語を切り替え、独自のラベル名と編集中の内容が残ることを確認します。
3. 画面から保存します。ログインとライセンスの確認後、ホストのコールバックで結果が書き込まれることを確認してください。
4. タスクを開き直し、保存済みの内容を確認します。

接続エラーの場合は `frameURL`、HTTPS、サービスが許可した Origin を確認します。CSP の設定と、外部データへの CORS も必要です。

## 通信仕様

Comlink と 2 つの MessagePort を使用します。接続時には Origin、送信元、ランダムなチャンネル、iframe の実体を検証します。構造化クローンにより Blob、Uint8Array などを転送します。通信の型は `@stardustai/annotation-client/protocol` から読み込めます。

## クライアントをビルドする

Rosetta リポジトリ内の client ディレクトリで実行します。先に schema-core を含む依存関係をインストールしてください。

```sh
npm run typecheck
npm test
npm run build
npm run release
```

TypeScript と Vite の出力先は `dist/` です。`release` は公開アーカイブを standalone ワークスペースの `vendor/` へ保存します。出力先は `package.json` で確認できます。各言語の README と、その言語のスクリーンショットもアーカイブに含まれます。
