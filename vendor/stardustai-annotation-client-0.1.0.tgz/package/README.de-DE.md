# @stardustai/annotation-client

[English](README.md) | [简体中文](README.zh-CN.md) | **Deutsch** | [日本語](README.ja-JP.md)

Dieser React-Client verbindet den Standalone-Arbeitsbereich über ein iframe mit dem Rosetta-Annotationsdienst. Er bietet die Zeichenfläche, die Werkzeugkonfiguration und die Algorithmuskonfiguration. Rendering und Anmeldung laufen im entfernten iframe.

![Über den Client eingebundener Editor auf Deutsch](docs/images/05-editor-de.jpg)

## Vorbereiten

Sie benötigen eine laufende Annotationsseite und deren vollständige HTTPS-Adresse. Der Dienst muss den Origin Ihrer Anwendung in `VITE_HOST_ORIGINS` erlauben. Der Origin besteht aus Schema, Host und gegebenenfalls Port; ein Anwendungspfad gehört nicht dazu.

## In die Anwendung einbinden

Rendern Sie die Komponenten innerhalb von `RosettaProvider`. Die hier verwendeten Daten und Callback-Funktionen stellt Ihre Anwendung bereit:

```tsx
import {
  configureRosetta,
  RosettaAnnotation,
  RosettaProvider,
} from '@stardustai/annotation-client';

configureRosetta({
  frameURL: 'https://annotation.example.com/',
  language: 'de-DE',
  readResource: readLocalBlobOrSignedURL,
  saveFile: persistGeneratedFile,
});

<RosettaProvider>
  <RosettaAnnotation
    taskId={task.id}
    input={task.input}
    language={language}
    onSave={saveTask}
    onProtectionSave={saveRecoveryDraft}
  />
</RosettaProvider>;
```

`task.input` hat den Typ `PublicAnnotationInput`; `language` ist beispielsweise `'de-DE'`. `readResource` liefert einen Blob oder eine signierte URL. `saveFile` speichert eine generierte Datei und gibt ihre Adresse zurück. `onSave` erhält Ergebnis, Parameter, Datenindex und Entwurf. Die Promise darf erst nach dem vollständigen Speichern auflösen. Ebenso muss `onProtectionSave` das Schreiben der lokalen Wiederherstellungskopie abwarten.

`OperatorsEditor` und `AlgorithmEditor` liefern Konfigurationsänderungen über `onInputChange`. Die Ref des Annotationseditors bietet `captureDraft`, `authorizeSave`, `confirmSave` und `authorizeExport`. Die Autorisierung erfolgt im Annotationsdienst.

## Sprachen wechseln

Englisch ist der Standard. Zur Auswahl stehen `en-US`, `zh-CN`, `de-DE` und `ja-JP`. Die globale Konfiguration setzt die Ausgangssprache; die `language`-Prop eines Editors hat Vorrang. Ohne diese Prop folgt der Client seiner gemeinsamen i18next-Instanz.

```tsx
<RosettaAnnotation input={input} language="ja-JP" />
```

Die erste iframe-URL enthält `lng`. Bei der Initialisierung wird derselbe Wert als `FrameInput.language` übertragen. Danach verwendet der Client das optionale `FrameEditor.setLanguage`. Ein Sprachwechsel ruft weder `updateInput` auf noch verbindet er das iframe neu. Der aktive Entwurf bleibt erhalten. Ältere Dienste dürfen die Methode weglassen; dann steht der laufende Sprachwechsel erst nach einem Dienstupdate zur Verfügung.

## Die Verbindung prüfen

1. Öffnen Sie ein Bild mit einem vorhandenen Werkzeugset. Im iframe müssen Daten und Werkzeugleiste erscheinen.
2. Wechseln Sie zwischen Deutsch und Japanisch. Die Oberfläche sollte wechseln, während eigene Labels und Bearbeitungen erhalten bleiben.
3. Speichern Sie über die Oberfläche. Nach Anmeldung und Lizenzprüfung muss der Host-Callback das Ergebnis schreiben.
4. Öffnen Sie die Aufgabe erneut und prüfen Sie den gespeicherten Stand.

Bei Verbindungsfehlern prüfen Sie `frameURL`, HTTPS und die erlaubten Origins des Dienstes. Die Seite benötigt außerdem eine passende CSP sowie CORS für externe Datenquellen.

## Protokoll

Comlink verwendet zwei MessagePorts. Der Verbindungsaufbau prüft Origin, Quelle, einen zufälligen Kanal und die iframe-Instanz. Strukturierte Klone übertragen unter anderem Blob und Uint8Array. Protokolltypen können Sie aus `@stardustai/annotation-client/protocol` importieren.

## Den Client bauen

Die folgenden Befehle werden im Clientverzeichnis des Rosetta-Repositorys ausgeführt. Zuvor müssen dessen Abhängigkeiten einschließlich schema-core installiert sein.

```sh
npm run typecheck
npm test
npm run build
npm run release
```

TypeScript und Vite schreiben die Ausgabe nach `dist/`. `release` legt das öffentliche Archiv im `vendor/`-Verzeichnis des Standalone-Arbeitsbereichs ab. Der Zielpfad steht in `package.json`. Die Sprachfassungen dieses Handbuchs und die dazugehörigen Screenshots sind im Archiv enthalten.
