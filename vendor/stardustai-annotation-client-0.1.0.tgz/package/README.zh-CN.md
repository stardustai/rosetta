# @stardustai/annotation-client

[English](README.md) | **简体中文**

React iframe 客户端，连接 annotation-tool 和 Rosetta 标注服务。提供标注画布、工具配置和算法配置三个入口。

源码位于 `packages/rosetta-annotation/client/`，与私有引擎一起维护，单独打包。宿主只需要这个客户端，标注引擎和登录逻辑由远程 iframe 提供。

```tsx
import { configureRosetta, RosettaAnnotation } from '@stardustai/annotation-client';

configureRosetta({
  frameURL: 'https://annotation.example.com/',
  readResource: readLocalBlobOrSignedURL,
  saveFile: persistGeneratedFile,
});

<RosettaAnnotation
  taskId={task.id}
  input={task.input}
  onSave={saveTask}
  onProtectionSave={saveRecoveryDraft}
/>;
```

`readResource` 返回 Blob 或签名 URL，`saveFile` 返回生成文件的地址。`onSave` 接收结果、参数、数据下标和草稿，写入完成后返回 Promise。

`OperatorsEditor` 和 `AlgorithmEditor` 通过 `onInputChange` 回传配置。标注组件的 ref 提供 `captureDraft`、`authorizeSave`、`confirmSave` 和 `authorizeExport`，授权由 iframe 内的标注服务执行。

通信使用 Comlink 和两个 MessagePort。握手校验 Origin、source 和随机 channel，数据通过结构化克隆传递，支持 Blob 和 Uint8Array。协议类型从 `@stardustai/annotation-client/protocol` 引入。

## 构建

```sh
npm run typecheck
npm test
npm run release
```

构建使用 TypeScript 和 Vite，需要仓库中的 schema-core。`release` 将安装包写入 `standalone/annotation-tool/vendor/`。
